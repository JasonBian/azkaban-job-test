import os

os.system("python test.py")

print "test is a file"
