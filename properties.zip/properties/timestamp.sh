timeString=$(date +%s)
echo '{"logdate" : '$timeString'}' > /Users/bianzexin/Downloads/time.txt