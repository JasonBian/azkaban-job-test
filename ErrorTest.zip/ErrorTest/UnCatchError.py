file_obj=open("test")
print "test a python job"