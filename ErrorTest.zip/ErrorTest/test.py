try:
	file=open('test')
except Exception,ex:
	print Exception,":",ex